// [[Rcpp::depends(RcppParallel)]]
#include <Rcpp.h>
#include <RcppParallel.h>
#include "re2/re2.h"

#include <string>
#include <vector>
#include <algorithm>
#include <cctype>

using namespace Rcpp;
using namespace RcppParallel;

// ---------------------------------------------------------------------------
// Regex matching via RE2 (parallel across vector elements)
//
// RE2 compiled pattern is immutable after construction — fully thread-safe.
// All threads share one re2::RE2 instance; no per-thread allocation needed.
// ---------------------------------------------------------------------------

struct RE2GrepWorker : public Worker {
    const std::vector<std::string>& haystack;
    const std::vector<bool>& is_na;
    const re2::RE2& re;
    RVector<int> out;   // 0 = no match, 1 = match, -1 = NA sentinel

    RE2GrepWorker(const std::vector<std::string>& haystack,
                  const std::vector<bool>& is_na,
                  const re2::RE2& re,
                  IntegerVector& out)
        : haystack(haystack), is_na(is_na), re(re), out(out) {}

    void operator()(std::size_t begin, std::size_t end) {
        for (std::size_t i = begin; i < end; ++i) {
            if (is_na[i]) {
                out[i] = NA_INTEGER;
            } else {
                out[i] = re2::RE2::PartialMatch(haystack[i], re) ? 1 : 0;
            }
        }
    }
};

// [[Rcpp::export]]
LogicalVector fast_grepl_impl(const std::string& pattern,
                               const StringVector& x,
                               bool ignore_case) {
    re2::RE2::Options opts;
    opts.set_case_sensitive(!ignore_case);
    // posix_syntax = false (default): Perl classes (\d, \s, \w) always available,
    // matching grepl(perl=TRUE) semantics as closely as RE2 allows.

    re2::RE2 re(pattern, opts);
    if (!re.ok()) {
        stop("Invalid RE2 pattern: %s", re.error().c_str());
    }

    const R_xlen_t n = x.size();
    std::vector<std::string> haystack(n);
    std::vector<bool> is_na(n, false);

    for (R_xlen_t i = 0; i < n; ++i) {
        if (x[i] == NA_STRING) {
            is_na[i] = true;
        } else {
            haystack[i] = Rcpp::as<std::string>(x[i]);
        }
    }

    IntegerVector raw(n, 0);
    RE2GrepWorker worker(haystack, is_na, re, raw);
    parallelFor(0, (std::size_t)n, worker);

    // Reinterpret int output as logical, preserving NA
    LogicalVector result(n);
    for (R_xlen_t i = 0; i < n; ++i) {
        if (raw[i] == NA_INTEGER) {
            result[i] = NA_LOGICAL;
        } else {
            result[i] = raw[i] != 0;
        }
    }
    return result;
}

// ---------------------------------------------------------------------------
// Fixed (literal) string matching — zero regex overhead.
// Case-insensitive path lowercases both needle and haystack (ASCII-safe).
// ---------------------------------------------------------------------------

static std::string ascii_tolower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(),
                   [](unsigned char c) { return (char)std::tolower(c); });
    return s;
}

struct FixedGrepWorker : public Worker {
    const std::vector<std::string>& haystack;
    const std::vector<bool>& is_na;
    const std::string& needle;
    RVector<int> out;

    FixedGrepWorker(const std::vector<std::string>& haystack,
                    const std::vector<bool>& is_na,
                    const std::string& needle,
                    IntegerVector& out)
        : haystack(haystack), is_na(is_na), needle(needle), out(out) {}

    void operator()(std::size_t begin, std::size_t end) {
        for (std::size_t i = begin; i < end; ++i) {
            if (is_na[i]) {
                out[i] = NA_INTEGER;
            } else {
                out[i] = (haystack[i].find(needle) != std::string::npos) ? 1 : 0;
            }
        }
    }
};

// [[Rcpp::export]]
LogicalVector fast_fixed_impl(const std::string& pattern,
                               const StringVector& x,
                               bool ignore_case) {
    const R_xlen_t n = x.size();
    const std::string needle = ignore_case ? ascii_tolower(pattern) : pattern;

    std::vector<std::string> haystack(n);
    std::vector<bool> is_na(n, false);

    for (R_xlen_t i = 0; i < n; ++i) {
        if (x[i] == NA_STRING) {
            is_na[i] = true;
        } else {
            std::string s = Rcpp::as<std::string>(x[i]);
            haystack[i] = ignore_case ? ascii_tolower(s) : s;
        }
    }

    IntegerVector raw(n, 0);
    FixedGrepWorker worker(haystack, is_na, needle, raw);
    parallelFor(0, (std::size_t)n, worker);

    LogicalVector result(n);
    for (R_xlen_t i = 0; i < n; ++i) {
        if (raw[i] == NA_INTEGER) {
            result[i] = NA_LOGICAL;
        } else {
            result[i] = raw[i] != 0;
        }
    }
    return result;
}
